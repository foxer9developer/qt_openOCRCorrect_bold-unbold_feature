/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../FrameWorkCode/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[46];
    char stringdata0[1296];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 22), // "on_actionNew_triggered"
QT_MOC_LITERAL(2, 34, 0), // ""
QT_MOC_LITERAL(3, 35, 23), // "on_actionOpen_triggered"
QT_MOC_LITERAL(4, 59, 23), // "on_actionSave_triggered"
QT_MOC_LITERAL(5, 83, 26), // "on_actionSave_As_triggered"
QT_MOC_LITERAL(6, 110, 30), // "on_actionSpell_Check_triggered"
QT_MOC_LITERAL(7, 141, 15), // "mousePressEvent"
QT_MOC_LITERAL(8, 157, 12), // "QMouseEvent*"
QT_MOC_LITERAL(9, 170, 2), // "ev"
QT_MOC_LITERAL(10, 173, 13), // "menuSelection"
QT_MOC_LITERAL(11, 187, 8), // "QAction*"
QT_MOC_LITERAL(12, 196, 6), // "action"
QT_MOC_LITERAL(13, 203, 33), // "on_actionLoad_Next_Page_trigg..."
QT_MOC_LITERAL(14, 237, 33), // "on_actionLoad_Prev_Page_trigg..."
QT_MOC_LITERAL(15, 271, 31), // "on_actionLoadGDocPage_triggered"
QT_MOC_LITERAL(16, 303, 31), // "on_actionToDevanagari_triggered"
QT_MOC_LITERAL(17, 335, 27), // "on_actionLoadData_triggered"
QT_MOC_LITERAL(18, 363, 27), // "on_actionLoadDict_triggered"
QT_MOC_LITERAL(19, 391, 31), // "on_actionLoadOCRWords_triggered"
QT_MOC_LITERAL(20, 423, 29), // "on_actionLoadDomain_triggered"
QT_MOC_LITERAL(21, 453, 28), // "on_actionLoadSubPS_triggered"
QT_MOC_LITERAL(22, 482, 33), // "on_actionLoadConfusions_trigg..."
QT_MOC_LITERAL(23, 516, 23), // "on_actionSugg_triggered"
QT_MOC_LITERAL(24, 540, 33), // "on_actionCreateBest2OCR_trigg..."
QT_MOC_LITERAL(25, 574, 25), // "on_actionToSlp1_triggered"
QT_MOC_LITERAL(26, 600, 38), // "on_actionCreateSuggestionLog_..."
QT_MOC_LITERAL(27, 639, 53), // "on_actionCreateSuggestionLogN..."
QT_MOC_LITERAL(28, 693, 36), // "on_actionErrorDetectionRep_tr..."
QT_MOC_LITERAL(29, 730, 47), // "on_actionErrorDetectWithoutAd..."
QT_MOC_LITERAL(30, 778, 24), // "on_actionCPair_triggered"
QT_MOC_LITERAL(31, 803, 27), // "on_actionToSlp1_2_triggered"
QT_MOC_LITERAL(32, 831, 24), // "on_actionToDev_triggered"
QT_MOC_LITERAL(33, 856, 29), // "on_actionExtractDev_triggered"
QT_MOC_LITERAL(34, 886, 36), // "on_actionPrimarySecOCRPair_tr..."
QT_MOC_LITERAL(35, 923, 39), // "on_actionCPairIEROcrVsCorrect..."
QT_MOC_LITERAL(36, 963, 30), // "on_actionEditDistRep_triggered"
QT_MOC_LITERAL(37, 994, 36), // "on_actionConfusionFreqHist_tr..."
QT_MOC_LITERAL(38, 1031, 39), // "on_actionCPairGEROcrVsCorrect..."
QT_MOC_LITERAL(39, 1071, 44), // "on_actionFilterOutGT50EditDis..."
QT_MOC_LITERAL(40, 1116, 34), // "on_actionPrepareFeatures_trig..."
QT_MOC_LITERAL(41, 1151, 40), // "on_actionErrorDetectionRepUni..."
QT_MOC_LITERAL(42, 1192, 27), // "on_actionSanskrit_triggered"
QT_MOC_LITERAL(43, 1220, 24), // "on_actionHindi_triggered"
QT_MOC_LITERAL(44, 1245, 26), // "on_actionEnglish_triggered"
QT_MOC_LITERAL(45, 1272, 23) // "on_actionBold_triggered"

    },
    "MainWindow\0on_actionNew_triggered\0\0"
    "on_actionOpen_triggered\0on_actionSave_triggered\0"
    "on_actionSave_As_triggered\0"
    "on_actionSpell_Check_triggered\0"
    "mousePressEvent\0QMouseEvent*\0ev\0"
    "menuSelection\0QAction*\0action\0"
    "on_actionLoad_Next_Page_triggered\0"
    "on_actionLoad_Prev_Page_triggered\0"
    "on_actionLoadGDocPage_triggered\0"
    "on_actionToDevanagari_triggered\0"
    "on_actionLoadData_triggered\0"
    "on_actionLoadDict_triggered\0"
    "on_actionLoadOCRWords_triggered\0"
    "on_actionLoadDomain_triggered\0"
    "on_actionLoadSubPS_triggered\0"
    "on_actionLoadConfusions_triggered\0"
    "on_actionSugg_triggered\0"
    "on_actionCreateBest2OCR_triggered\0"
    "on_actionToSlp1_triggered\0"
    "on_actionCreateSuggestionLog_triggered\0"
    "on_actionCreateSuggestionLogNearestPriority_triggered\0"
    "on_actionErrorDetectionRep_triggered\0"
    "on_actionErrorDetectWithoutAdaptation_triggered\0"
    "on_actionCPair_triggered\0"
    "on_actionToSlp1_2_triggered\0"
    "on_actionToDev_triggered\0"
    "on_actionExtractDev_triggered\0"
    "on_actionPrimarySecOCRPair_triggered\0"
    "on_actionCPairIEROcrVsCorrect_triggered\0"
    "on_actionEditDistRep_triggered\0"
    "on_actionConfusionFreqHist_triggered\0"
    "on_actionCPairGEROcrVsCorrect_triggered\0"
    "on_actionFilterOutGT50EditDisPairs_triggered\0"
    "on_actionPrepareFeatures_triggered\0"
    "on_actionErrorDetectionRepUniq_triggered\0"
    "on_actionSanskrit_triggered\0"
    "on_actionHindi_triggered\0"
    "on_actionEnglish_triggered\0"
    "on_actionBold_triggered"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      40,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  214,    2, 0x08 /* Private */,
       3,    0,  215,    2, 0x08 /* Private */,
       4,    0,  216,    2, 0x08 /* Private */,
       5,    0,  217,    2, 0x08 /* Private */,
       6,    0,  218,    2, 0x08 /* Private */,
       7,    1,  219,    2, 0x08 /* Private */,
      10,    1,  222,    2, 0x08 /* Private */,
      13,    0,  225,    2, 0x08 /* Private */,
      14,    0,  226,    2, 0x08 /* Private */,
      15,    0,  227,    2, 0x08 /* Private */,
      16,    0,  228,    2, 0x08 /* Private */,
      17,    0,  229,    2, 0x08 /* Private */,
      18,    0,  230,    2, 0x08 /* Private */,
      19,    0,  231,    2, 0x08 /* Private */,
      20,    0,  232,    2, 0x08 /* Private */,
      21,    0,  233,    2, 0x08 /* Private */,
      22,    0,  234,    2, 0x08 /* Private */,
      23,    0,  235,    2, 0x08 /* Private */,
      24,    0,  236,    2, 0x08 /* Private */,
      25,    0,  237,    2, 0x08 /* Private */,
      26,    0,  238,    2, 0x08 /* Private */,
      27,    0,  239,    2, 0x08 /* Private */,
      28,    0,  240,    2, 0x08 /* Private */,
      29,    0,  241,    2, 0x08 /* Private */,
      30,    0,  242,    2, 0x08 /* Private */,
      31,    0,  243,    2, 0x08 /* Private */,
      32,    0,  244,    2, 0x08 /* Private */,
      33,    0,  245,    2, 0x08 /* Private */,
      34,    0,  246,    2, 0x08 /* Private */,
      35,    0,  247,    2, 0x08 /* Private */,
      36,    0,  248,    2, 0x08 /* Private */,
      37,    0,  249,    2, 0x08 /* Private */,
      38,    0,  250,    2, 0x08 /* Private */,
      39,    0,  251,    2, 0x08 /* Private */,
      40,    0,  252,    2, 0x08 /* Private */,
      41,    0,  253,    2, 0x08 /* Private */,
      42,    0,  254,    2, 0x08 /* Private */,
      43,    0,  255,    2, 0x08 /* Private */,
      44,    0,  256,    2, 0x08 /* Private */,
      45,    0,  257,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 8,    9,
    QMetaType::Void, 0x80000000 | 11,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_actionNew_triggered(); break;
        case 1: _t->on_actionOpen_triggered(); break;
        case 2: _t->on_actionSave_triggered(); break;
        case 3: _t->on_actionSave_As_triggered(); break;
        case 4: _t->on_actionSpell_Check_triggered(); break;
        case 5: _t->mousePressEvent((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 6: _t->menuSelection((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        case 7: _t->on_actionLoad_Next_Page_triggered(); break;
        case 8: _t->on_actionLoad_Prev_Page_triggered(); break;
        case 9: _t->on_actionLoadGDocPage_triggered(); break;
        case 10: _t->on_actionToDevanagari_triggered(); break;
        case 11: _t->on_actionLoadData_triggered(); break;
        case 12: _t->on_actionLoadDict_triggered(); break;
        case 13: _t->on_actionLoadOCRWords_triggered(); break;
        case 14: _t->on_actionLoadDomain_triggered(); break;
        case 15: _t->on_actionLoadSubPS_triggered(); break;
        case 16: _t->on_actionLoadConfusions_triggered(); break;
        case 17: _t->on_actionSugg_triggered(); break;
        case 18: _t->on_actionCreateBest2OCR_triggered(); break;
        case 19: _t->on_actionToSlp1_triggered(); break;
        case 20: _t->on_actionCreateSuggestionLog_triggered(); break;
        case 21: _t->on_actionCreateSuggestionLogNearestPriority_triggered(); break;
        case 22: _t->on_actionErrorDetectionRep_triggered(); break;
        case 23: _t->on_actionErrorDetectWithoutAdaptation_triggered(); break;
        case 24: _t->on_actionCPair_triggered(); break;
        case 25: _t->on_actionToSlp1_2_triggered(); break;
        case 26: _t->on_actionToDev_triggered(); break;
        case 27: _t->on_actionExtractDev_triggered(); break;
        case 28: _t->on_actionPrimarySecOCRPair_triggered(); break;
        case 29: _t->on_actionCPairIEROcrVsCorrect_triggered(); break;
        case 30: _t->on_actionEditDistRep_triggered(); break;
        case 31: _t->on_actionConfusionFreqHist_triggered(); break;
        case 32: _t->on_actionCPairGEROcrVsCorrect_triggered(); break;
        case 33: _t->on_actionFilterOutGT50EditDisPairs_triggered(); break;
        case 34: _t->on_actionPrepareFeatures_triggered(); break;
        case 35: _t->on_actionErrorDetectionRepUniq_triggered(); break;
        case 36: _t->on_actionSanskrit_triggered(); break;
        case 37: _t->on_actionHindi_triggered(); break;
        case 38: _t->on_actionEnglish_triggered(); break;
        case 39: _t->on_actionBold_triggered(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 6:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QAction* >(); break;
            }
            break;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 40)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 40;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 40)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 40;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
